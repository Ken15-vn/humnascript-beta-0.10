import time
import os
import sys

# Kho lưu trữ biến số cho phiên bản 0.10
variables = {}

def run_human_script(file_path):
    # Bảng màu kế thừa từ bản 0.05
    colors = {
        "green": "\033[92m",
        "red": "\033[91m",
        "yellow": "\033[93m",
        "blue": "\033[94m",
        "cyan": "\033[96m",
        "white": "\033[0m"
    }

    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            lines = file.readlines()

        for line in lines:
            line = line.strip()
            if not line or line.startswith("#"): 
                continue

            # --- TÍNH NĂNG KẾ THỪA TỪ 0.05 ---
            
            # Lệnh wait: Tạm dừng chương trình
            if line.startswith("wait "):
                time.sleep(float(line[5:]))
            
            # Lệnh clear: Dọn dẹp màn hình console
            elif line == "clear":
                os.system('cls' if os.name == 'nt' else 'clear')
            
            # Lệnh color: Đổi màu chữ
            elif line.startswith("color "):
                c = line[6:].strip().strip('"').lower()
                if c in colors:
                    sys.stdout.write(colors[c])

            # --- TÍNH NĂNG MỚI CỦA 0.10 ---

            # Lệnh set: Khởi tạo biến (Ví dụ: set "diem" 100)
            elif line.startswith("set "):
                parts = line.split()
                if len(parts) >= 3:
                    var_name = parts[1].strip('"')
                    var_value = float(parts[2])
                    variables[var_name] = var_value

            # Lệnh add: Cộng giá trị vào biến
            elif line.startswith("add "):
                parts = line.split()
                if len(parts) >= 3:
                    var_name = parts[1].strip('"')
                    add_value = float(parts[2])
                    if var_name in variables:
                        variables[var_name] += add_value

            # Lệnh write: Cải tiến để in được cả chữ và biến
            elif line.startswith("write "):
                content = line[6:].strip().strip('"')
                # Nếu nội dung trùng với tên biến, in giá trị biến đó ra
                if content in variables:
                    print(variables[content])
                else:
                    print(content)

    except Exception as e:
        print(f"Lỗi thực thi: {e}")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        run_human_script(sys.argv[1])
    else:
        # Hướng dẫn kế thừa từ cấu trúc cũ
        print("Huong dan: python humanscript_0.10.py <file.human>")