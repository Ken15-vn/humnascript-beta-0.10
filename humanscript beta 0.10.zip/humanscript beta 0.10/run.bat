@echo off
python humanscript_beta_0.10.py ide.human
pause